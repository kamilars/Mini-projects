#ifndef SRC_MY_MASTERMIND_1_H_
#define SRC_MY_MASTERMIND_1_H_

int my_strcmp(char* param_1, char* param_2);

int my_atoi(char* str);

char* my_rand();

char* my_strcpy(char* param_1, char* param_2);


#endif